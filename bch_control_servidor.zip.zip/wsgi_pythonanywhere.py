"""Plantilla WSGI para publicar el ERP V2 en PythonAnywhere."""

import os
import sys


USERNAME = "TU_USUARIO_PYTHONANYWHERE"
PROJECT_DIR = f"/home/{USERNAME}/erp_v2"

if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

# Este punto de entrada nunca debe heredar accidentalmente el modo desarrollo.
os.environ["FLASK_ENV"] = "production"

secret_key = os.getenv("SECRET_KEY", "").strip()
unsafe_markers = (
    "reemplazar",
    "cambia-esto",
    "clave-secreta-para-desarrollo",
    "genera_una_clave",
    "genera-una-clave",
    "tu_clave",
    "tu-clave",
    "secret-key",
    "changeme",
    "example",
    "ejemplo",
)
if len(secret_key) < 32 or any(
    marker in secret_key.lower() for marker in unsafe_markers
):
    raise RuntimeError(
        "ERROR CRÍTICO: SECRET_KEY no configurada o insegura. Define una clave "
        "aleatoria de al menos 32 caracteres en las variables de entorno."
    )

database_url = os.getenv("DATABASE_URL", "").strip()
database_scheme = database_url.lower()
if not database_url or not database_scheme.startswith(
    ("postgres://", "postgresql://", "postgresql+psycopg2://")
):
    raise RuntimeError(
        "ERROR CRÍTICO: producción requiere una DATABASE_URL de PostgreSQL."
    )

from app import create_app  # noqa: E402


application = create_app()
